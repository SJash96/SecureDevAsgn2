from django.apps import AppConfig


class ThreadappConfig(AppConfig):
    name = 'threadApp'
